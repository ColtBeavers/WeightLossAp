package com.example.weightlossapplication;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class User {

    @PrimaryKey(autoGenerate = true)
    private long id;

    @NonNull
    private final String username;

    @NonNull
    private final String password;

    public User(@NonNull String username, @NonNull String password) {
        this.username = username;
        this.password = password;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    @NonNull public String getUsername() { return username; }

    @NonNull public String getPassword() { return password; }
}
