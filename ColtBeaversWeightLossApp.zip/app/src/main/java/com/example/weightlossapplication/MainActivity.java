package com.example.weightlossapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEt, passwordEt;

    private UserDao userDao;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        usernameEt = findViewById(R.id.UsernameEditText);
        passwordEt = findViewById(R.id.PasswordEditText);
        Button signInBtn = findViewById(R.id.signInButton);

        WeightDatabase db = Room.databaseBuilder(getApplicationContext(), WeightDatabase.class, "weights.db")
                .build();
        userDao = db.userDao();

        signInBtn.setOnClickListener(v -> {
            String user = usernameEt.getText().toString().trim();
            String pass = passwordEt.getText().toString().trim();

            if (TextUtils.isEmpty(user)) { usernameEt.setError("Username required"); return; }
            if (TextUtils.isEmpty(pass)) { passwordEt.setError("Password required"); return; }

            io.execute(() -> {
                User existing = userDao.getByUsername(user);
                runOnUiThread(() -> {
                    if (existing == null) {

                        Intent i = new Intent(MainActivity.this, CreateAccount.class);
                        startActivity(i);
                    } else if (!existing.getPassword().equals(pass)) {
                        Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show();
                    } else {

                        Intent i = new Intent(MainActivity.this, WeightGrid.class);
                        i.putExtra("user_id", existing.getId());
                        startActivity(i);
                    }
                });
            });
        });
    }
}
