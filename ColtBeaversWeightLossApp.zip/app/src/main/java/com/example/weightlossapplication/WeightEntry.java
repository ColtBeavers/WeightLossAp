package com.example.weightlossapplication;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Ignore;

@Entity(tableName = "weights")
public class WeightEntry {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private final long userId;

    @NonNull
    private String weight;

    @NonNull
    private String date; // mm-dd-yyyy

    public WeightEntry(@NonNull String weight, @NonNull String date, long userId) {
        this.weight = weight;
        this.date = date;
        this.userId = userId;
    }

    @Ignore
    public WeightEntry(@NonNull String weight, @NonNull String date) {
        this(weight, date, 0L);
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getUserId() { return userId; }

    @NonNull public String getWeight() { return weight; }
    public void setWeight(@NonNull String weight) { this.weight = weight; }

    @NonNull public String getDate() { return date; }
    public void setDate(@NonNull String date) { this.date = date; }
}
