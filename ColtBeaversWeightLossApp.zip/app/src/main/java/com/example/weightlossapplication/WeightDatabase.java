package com.example.weightlossapplication;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(
        entities = {
                WeightEntry.class,
                Goal.class,
                User.class
        },
        version = 6,
        exportSchema = false
)
public abstract class WeightDatabase extends RoomDatabase {
    public abstract WeightDao weightDao();
    public abstract GoalDao goalDao();
    public abstract UserDao userDao();
}

