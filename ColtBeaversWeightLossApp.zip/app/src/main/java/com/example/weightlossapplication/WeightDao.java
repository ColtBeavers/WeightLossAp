package com.example.weightlossapplication;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WeightDao {

    // READ only this user's rows
    @Query("SELECT * FROM weights WHERE userId = :userId ORDER BY date DESC, id DESC")
    List<WeightEntry> getAllForUser(long userId);

    @Insert
    long insert(WeightEntry entry);

    @Delete
    void delete(WeightEntry entry);

    @Query("DELETE FROM weights WHERE id = :id")
    void deleteById(long id);

    @Query("UPDATE weights SET weight = :newWeight, date = :newDate WHERE id = :id")
    void update(long id, String newWeight, String newDate);

    @Query("SELECT * FROM weights WHERE id = :id LIMIT 1")
    WeightEntry getById(long id);
}

