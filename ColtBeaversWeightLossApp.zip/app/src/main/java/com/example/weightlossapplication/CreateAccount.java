package com.example.weightlossapplication;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CreateAccount extends AppCompatActivity {

    private EditText usernameET, passwordEt;

    private UserDao userDao;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        usernameET = findViewById(R.id.UsernameEditText);
        passwordEt = findViewById(R.id.PasswordEditText);
        Button createBtn = findViewById(R.id.btnCreate);

        WeightDatabase db = Room.databaseBuilder(getApplicationContext(), WeightDatabase.class, "weights.db")
                .build();
        userDao = db.userDao();

        createBtn.setOnClickListener(v -> {
            String u = usernameET.getText().toString().trim();
            String p = passwordEt.getText().toString().trim();

            if (TextUtils.isEmpty(u)) { usernameET.setError("Username required"); return; }
            if (TextUtils.isEmpty(p)) { passwordEt.setError("Password required"); return; }

            io.execute(() -> {
                User existing = userDao.getByUsername(u);
                if (existing != null) {
                    runOnUiThread(() ->
                            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
                    );
                    return;
                }

                long newUserId = userDao.insert(new User(u, p));
                runOnUiThread(() -> {
                    if (newUserId > 0) {
                        Toast.makeText(this, "Account created!", Toast.LENGTH_SHORT).show();
                        android.content.Intent i = new android.content.Intent(this, WeightGrid.class);
                        i.putExtra("user_id", newUserId);
                        startActivity(i);
                        finish();
                    } else {
                        Toast.makeText(this, "Failed to create account", Toast.LENGTH_SHORT).show();
                    }
                });
            });
        });
    }
}
