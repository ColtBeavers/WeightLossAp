package com.example.weightlossapplication;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "goals")
public class Goal {

    @PrimaryKey
    public long userId;

    public double goalLbs;

    public Goal(long userId, double goalLbs) {
        this.userId = userId;
        this.goalLbs = goalLbs;
    }
}

