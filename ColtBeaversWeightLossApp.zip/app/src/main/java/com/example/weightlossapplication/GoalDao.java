package com.example.weightlossapplication;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface GoalDao {

    @Query("SELECT * FROM goals WHERE userId = :userId LIMIT 1")
    Goal getGoal(long userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void upsert(Goal goal);
}
