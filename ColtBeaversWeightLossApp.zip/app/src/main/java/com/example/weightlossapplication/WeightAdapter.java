package com.example.weightlossapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.VH> {

    public interface OnDeleteListener {
        void onDelete(int position, WeightEntry item);
    }

    public interface OnItemClickListener {
        void onClick(int position, WeightEntry item);
    }

    private final List<WeightEntry> items;
    private final OnDeleteListener onDelete;
    private final OnItemClickListener onItemClick;

    public WeightAdapter(List<WeightEntry> items,
                         OnDeleteListener onDelete,
                         OnItemClickListener onItemClick) {
        this.items = items;
        this.onDelete = onDelete;
        this.onItemClick = onItemClick;
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvWeight, tvDate;
        Button btnDelete;

        VH(@NonNull View itemView) {
            super(itemView);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            tvDate   = itemView.findViewById(R.id.tvDate);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        WeightEntry item = items.get(position);
        holder.tvWeight.setText(item.getWeight());
        holder.tvDate.setText(item.getDate());

        holder.btnDelete.setOnClickListener(view -> {
            int pos = holder.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) {
                onDelete.onDelete(pos, items.get(pos));
            }
        });

        holder.itemView.setOnClickListener(view -> {
            int pos = holder.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION && onItemClick != null) {
                onItemClick.onClick(pos, items.get(pos));
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // convenience methods
    public void addItem(WeightEntry item) {
        items.add(0, item);
        notifyItemInserted(0);
    }

    public void removeAt(int position) {
        if (position >= 0 && position < items.size()) {
            items.remove(position);
            notifyItemRemoved(position);
        }
    }
}

