package com.example.weightlossapplication;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class WeightGrid extends AppCompatActivity {

    private static final String PREFS = "sms_prefs";
    private static final String KEY_SMS_ENABLED_PREFIX = "sms_enabled_user_";
    private static final String KEY_SMS_PHONE_PREFIX = "sms_phone_user_";
    private static final int REQ_SEND_SMS = 1001;

    private WeightAdapter adapter;
    private TextView tvGoal, tvDelta;

    private final List<WeightEntry> data = new ArrayList<>();

    private WeightDao weightDao;
    private GoalDao goalDao;

    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private static final SimpleDateFormat DF = new SimpleDateFormat("MM-dd-yyyy", Locale.US);

    private long currentUserId = 0L;

    private boolean smsEnabled = false;
    private String smsPhone = "";

    @SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_grid);

        RecyclerView recycler = findViewById(R.id.recycler);
        FloatingActionButton addButton = findViewById(R.id.addButton);
        Button btnSetGoal = findViewById(R.id.btnSetGoal);
        Button btnSetPhone = findViewById(R.id.btnSetPhone);
        tvGoal     = findViewById(R.id.tvGoal);
        tvDelta    = findViewById(R.id.tvDelta);
        CheckBox cbEnableSms = findViewById(R.id.cbEnableSms);

        currentUserId = getIntent().getLongExtra("user_id", 0L);

        loadSmsPrefs();

        WeightDatabase db = Room.databaseBuilder(
                getApplicationContext(),
                WeightDatabase.class,
                "weights.db"
        ).build();
        weightDao = db.weightDao();
        goalDao   = db.goalDao();

        adapter = new WeightAdapter(
                data,
                (position, item) -> {
                    long id = item.getId();
                    io.execute(() -> {
                        weightDao.deleteById(id);
                        runOnUiThread(() -> {
                            adapter.removeAt(position);
                            updateGoalDeltaUI();
                        });
                    });
                },
                this::showEditDialog
        );

        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.setAdapter(adapter);
        recycler.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        io.execute(() -> {
            List<WeightEntry> all = weightDao.getAllForUser(currentUserId);
            Goal goal = goalDao.getGoal(currentUserId);
            runOnUiThread(() -> {
                data.clear();
                data.addAll(all);
                adapter.notifyDataSetChanged();

                if (goal != null) {
                    tvGoal.setText(String.format(Locale.US, "Goal: %.1f lb", goal.goalLbs));
                } else {
                    tvGoal.setText("Goal: —");
                }
                updateGoalDeltaUI();
            });
        });

        addButton.setOnClickListener(v -> {
            android.widget.LinearLayout container = new android.widget.LinearLayout(this);
            container.setOrientation(android.widget.LinearLayout.VERTICAL);
            int pad = (int) (16 * getResources().getDisplayMetrics().density);
            container.setPadding(pad, pad, pad, pad);

            final android.widget.EditText weightEt = new android.widget.EditText(this);
            weightEt.setHint("Weight (e.g., 182 lb or 82.5 kg)");
            weightEt.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
            container.addView(weightEt);

            final android.widget.EditText dateEt = new android.widget.EditText(this);
            dateEt.setHint("Date (MM-dd-yyyy)");
            String today = DF.format(new Date());
            dateEt.setText(today);
            dateEt.setInputType(android.text.InputType.TYPE_CLASS_DATETIME);
            container.addView(dateEt);

            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Add Weight")
                    .setView(container)
                    .setPositiveButton("Add", (d, which) -> {
                        String w = weightEt.getText().toString().trim();
                        String dt = dateEt.getText().toString().trim();

                        if (w.isEmpty()) {
                            android.widget.Toast.makeText(this, "Please enter a weight", android.widget.Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (dt.isEmpty()) {
                            android.widget.Toast.makeText(this, "Please enter a date", android.widget.Toast.LENGTH_SHORT).show();
                            return;
                        }

                        WeightEntry entry = new WeightEntry(w, dt, currentUserId);
                        io.execute(() -> {
                            long id = weightDao.insert(entry);
                            entry.setId(id);
                            runOnUiThread(() -> {
                                adapter.addItem(entry);
                                updateGoalDeltaUI();
                            });
                        });
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        btnSetGoal.setOnClickListener(v -> {
            final android.widget.EditText goalEt = new android.widget.EditText(this);
            goalEt.setHint("Goal (e.g., 170 lb or 77.1 kg)");
            goalEt.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
            int pad = (int) (16 * getResources().getDisplayMetrics().density);
            goalEt.setPadding(pad, pad, pad, pad);

            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Set Goal Weight")
                    .setView(goalEt)
                    .setPositiveButton("Save", (d, which) -> {
                        String text = goalEt.getText().toString().trim();
                        if (text.isEmpty()) {
                            android.widget.Toast.makeText(this, "Please enter a goal", android.widget.Toast.LENGTH_SHORT).show();
                            return;
                        }
                        double lbs = parseWeightToLbs(text);
                        io.execute(() -> {
                            goalDao.upsert(new Goal(currentUserId, lbs));
                            runOnUiThread(() -> {
                                tvGoal.setText(String.format(Locale.US, "Goal: %.1f lb", lbs));
                                updateGoalDeltaUI();
                            });
                        });
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        btnSetPhone.setOnClickListener(v -> {
            final android.widget.EditText phoneEt = new android.widget.EditText(this);
            phoneEt.setHint("10-digit phone (e.g., 5551234567)");
            phoneEt.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
            phoneEt.setText(smsPhone);
            int pad = (int) (16 * getResources().getDisplayMetrics().density);
            phoneEt.setPadding(pad, pad, pad, pad);

            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Set SMS Phone")
                    .setView(phoneEt)
                    .setPositiveButton("Save", (d, which) -> {
                        smsPhone = phoneEt.getText().toString().trim();
                        saveSmsPrefs();
                        android.widget.Toast.makeText(this, "Phone saved", android.widget.Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        cbEnableSms.setOnCheckedChangeListener((buttonView, isChecked) -> {
            smsEnabled = isChecked;
            saveSmsPrefs();
            if (isChecked) {
                ensureSmsPermissionOrExplain();
            }
        });

        cbEnableSms.setChecked(smsEnabled);
    }

    private void ensureSmsPermissionOrExplain() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            return;
        }
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                REQ_SEND_SMS
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                android.widget.Toast.makeText(this, "SMS permission granted", android.widget.Toast.LENGTH_SHORT).show();
            } else {
                android.widget.Toast.makeText(this, "SMS permission denied — alerts will not be sent via SMS", android.widget.Toast.LENGTH_LONG).show();
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private void updateGoalDeltaUI() {
        io.execute(() -> {
            Goal goal = goalDao.getGoal(currentUserId);
            Double latestLbs = getLatestWeightInLbsForCurrentUser();
            runOnUiThread(() -> {
                if (goal == null) {
                    tvDelta.setText("— from goal");
                    return;
                }
                if (latestLbs == null) {
                    tvDelta.setText("No weights yet");
                    return;
                }
                double diff = latestLbs - goal.goalLbs;
                String direction = diff > 0 ? "above" : (diff < 0 ? "below" : "at");
                double abs = Math.abs(diff);
                if ("at".equals(direction)) {
                    tvDelta.setText("At goal");
                    maybeSendGoalReachedSms(latestLbs, goal.goalLbs);
                } else {
                    tvDelta.setText(String.format(Locale.US, "%.1f lb %s goal", abs, direction));
                }
            });
        });
    }

    private void maybeSendGoalReachedSms(double latest, double goalLbs) {
        if (!smsEnabled) return;
        if (smsPhone == null || smsPhone.trim().isEmpty()) return;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ensureSmsPermissionOrExplain();
            return;
        }

        String msg = String.format(Locale.US,
                "Congrats! You reached your goal weight: %.1f lb (goal: %.1f lb). 🎉",
                latest, goalLbs);

        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(smsPhone, null, msg, null, null);
            android.widget.Toast.makeText(this, "Goal alert sent via SMS", android.widget.Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void loadSmsPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        smsEnabled = sp.getBoolean(KEY_SMS_ENABLED_PREFIX + currentUserId, false);
        smsPhone   = sp.getString(KEY_SMS_PHONE_PREFIX   + currentUserId, "");
    }

    private void saveSmsPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        sp.edit()
                .putBoolean(KEY_SMS_ENABLED_PREFIX + currentUserId, smsEnabled)
                .putString(KEY_SMS_PHONE_PREFIX + currentUserId, smsPhone)
                .apply();
    }

    private Double getLatestWeightInLbsForCurrentUser() {
        if (data.isEmpty()) return null;
        List<WeightEntry> copy = new ArrayList<>(data);
        try {
            copy.sort((a, b) -> {
                Date da = parseDate(a.getDate());
                Date db = parseDate(b.getDate());
                if (da == null && db == null) return 0;
                if (da == null) return 1;
                if (db == null) return -1;
                return db.compareTo(da);
            });
        } catch (Exception ignored) {}
        WeightEntry latest = copy.get(0);
        return parseWeightToLbs(latest.getWeight());
    }

    private Date parseDate(String s) {
        try {
            return DF.parse(s);
        } catch (ParseException e) {
            return null;
        }
    }

    private double parseWeightToLbs(String s) {
        if (s == null) return 0.0;
        String lower = s.trim().toLowerCase(Locale.US);
        boolean isKg = lower.contains("kg");
        String[] parts = lower.replaceAll("[^0-9.]+", " ").trim().split("\\s+");
        double value = 0.0;
        if (parts.length > 0) {
            try { value = Double.parseDouble(parts[0]); } catch (Exception ignored) {}
        }
        return isKg ? value * 2.2046226218 : value;
    }

    private void showEditDialog(int position, WeightEntry item) {
        android.widget.LinearLayout container = new android.widget.LinearLayout(this);
        container.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        container.setPadding(pad, pad, pad, pad);

        final android.widget.EditText weightEt = new android.widget.EditText(this);
        weightEt.setHint("Weight (e.g., 182 lb or 82.5 kg)");
        weightEt.setText(item.getWeight());
        container.addView(weightEt);

        final android.widget.EditText dateEt = new android.widget.EditText(this);
        dateEt.setHint("Date (MM-dd-yyyy)");
        dateEt.setText(item.getDate());
        container.addView(dateEt);

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Edit Weight")
                .setView(container)
                .setPositiveButton("Save", (d, which) -> {
                    String newWeight = weightEt.getText().toString().trim();
                    String newDate = dateEt.getText().toString().trim();

                    if (newWeight.isEmpty()) {
                        android.widget.Toast.makeText(this, "Weight required", android.widget.Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (newDate.isEmpty()) {
                        android.widget.Toast.makeText(this, "Date required", android.widget.Toast.LENGTH_SHORT).show();
                        return;
                    }

                    long id = item.getId();
                    io.execute(() -> {
                        weightDao.update(id, newWeight, newDate);
                        runOnUiThread(() -> {
                            item.setWeight(newWeight);
                            item.setDate(newDate);
                            adapter.notifyItemChanged(position);
                            updateGoalDeltaUI();
                        });
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
